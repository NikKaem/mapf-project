# Plans

The plan files look like this:  
planNr_SubNr.lp  
  
Nr indicates which instance the plan belongs to.
SubNr indicates which robot the plan belongs to. If there is no SubNr the plan is the merged plan for the whole instance.
