# Plan-Merging

## About
This is the repository for the plan merging project for the asprilo framework.

## Instances
The directory instances contains the instances used as benchmarks.

## Encoding
The directory encoding contains the encodings used to generate and merge plans.

## Plans
The directory plans contains the plans that are generated for the benchmarks.
