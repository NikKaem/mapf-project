# Encoding

## input.lp
input.lp transforms the input from the instance files to something that is easier to read.  

## action.lp
action.lp generates the plan.

## goal.lp
goal.lp defines the conditions which a plan must uphold.

## encoding.lp
encoding.lp includes the the above mentioned files and generates the output.

## merging.lp
merging.lp merges plans to a new plan without collisions.

## renaming.lp
renaming.lp transforms the output of the merging file to a plan the asprilo visualizer can use.
