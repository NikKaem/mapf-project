## moving obstacles

This benchmark and its simpler/harder variations attempt to simulate moving objects in form of robots (robot 3-6). The paths of those, in form of their positions at every timestep, will be included in the instance in the future. Robot 1 and 2 have to be aware of them, dodge or wait respectively to reach their assigned shelf.

 The purpose of these benchmarks is to make simpler scenarios (two robots in a small sized warehouse) the planning progress more complicated.
