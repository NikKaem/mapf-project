## benchmarks
In here you'll find a variety of benchmarks that attempt to test for specific scenarios and behaviors.
To learn more about each benchmark check out it's designated readme file.
