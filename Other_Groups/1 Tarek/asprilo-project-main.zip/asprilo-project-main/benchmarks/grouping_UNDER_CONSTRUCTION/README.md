## grouping/convoy
This benchmark is still in its design phase. It may not do what it should yet.
Its future purpose is to test for 'group thinking'. This aims at creating a scenario where the behaviour of the robots should mimic a convoy to solve the instance efficiently.
