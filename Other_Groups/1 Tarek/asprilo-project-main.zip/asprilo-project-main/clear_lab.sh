#!/bin/bash

rm lab/individual_plans/plan_r1.lp
rm lab/individual_plans/plan_r2.lp
rm lab/merged_plan.lp
