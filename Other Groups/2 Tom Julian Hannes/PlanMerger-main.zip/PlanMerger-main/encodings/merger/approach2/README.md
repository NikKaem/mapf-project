# Approach 2

Currently (version 2) merger encodings include all needed instances and should be run alone. Identical Versions with different instances are noted with \_N.

- **Version 1**
    + Same as approach 1 version 1
- **Version 2**
    + Delays one robot if collision detected
    + Checks solutions for new crashes and fixes them through iterations
    + Does not fullfil Edge Constraints
    + Benchmark tests with instances 1 and 5 were successful

