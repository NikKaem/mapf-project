# Benchmark 3 - Multi Robot Vertex Constraint



## Description

This Benchmark tackles again the problem of Vertex conflicts. This time instead of just two Robots, this benchmark contains four Robots which encounter a vertex conflict.



Image_1 : Map View of Benchmark 3

![Map View of Benchmark 3](map.png "Map View of Benchmark 3") 



This Benchmark is split into four separate instances `robot_1_instance/`, `robot_2_instance/`, `robot_3_instance/`and `robot_4_instance/` for the Plan-Merging-Project. 

The separate Plans for all robots are found in the `plans/` directory